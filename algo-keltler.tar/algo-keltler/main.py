from time import sleep
import MetaTrader5 as mt5

from pobieranie.pobranieDanych import PobranieDanych
# from warunkiWejWyj.warunki import open_long_position, open_short_position
from warunkiWejWyj.warunkiKeltnerCh import open_long_position, open_short_position

# Na Ninjatraderze jest to strategia o nazwie BolllingerBands coś tam i trójka na końcu

def main():
    mt5.initialize()

    while True:
        dane = PobranieDanych(symbol = 'EURUSD.pro', timeframe = mt5.TIMEFRAME_M5, start = 0, end = 1000)
        open_long_position(dane, 'EURUSD.pro')
        open_short_position(dane, 'EURUSD.pro')
        sleep(1)


if __name__ == '__main__':
    main()